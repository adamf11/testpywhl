#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import os
import pika
from implementations.rabbitmq import consume_event as consume
from implementations.rabbitmq import listen_event as listen
from implementations.rabbitmq import publish_event as publish
from implementations.rabbitmq import send_event as send
from implementations.rabbitmq import get_queue_message as queue
from implementations.rabbitmq import get_topic_message as topic
from implementations.rabbitmq import send_request as request
from implementations.rabbitmq import monitor_requests as monitor
from implementations.rabbitmq import join_group as group
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

os.environ["PROJECT_PATH"] = "/"

RMQ_URL = os.getenv("RMQ_URL", "")


class rabbitmq_handler:

    # Init Operations
    def __init__(self, connection_string, connection_port):
        vlog.info(f"RMQ_HANDLER: __init__")
        self.connection_string = connection_string
        try:
            self.connection = pika.BlockingConnection(
                pika.ConnectionParameters(connection_string)
            )
        except Exception as ex:
            vlog.error(
                f"RMQ_HANDLER: Error attempting to connect to the RabbitMQ server!",
                exc_info=True,
            )

    def getConnection():
        vlog.info(f"RMQ_HANDLER: Getting connection object")

    # Primary Functions
    async def sendEvent(self, channel_name, json_msg):
        vlog.info(f"RMQ_HANDLER: Creating event on queue")
        await send.sendEvent(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            json_msg,
        )

    async def publishEvent(self, channel_name, json_msg):
        vlog.info(f"RMQ_HANDLER: Publishing event to topic")
        await publish.publishEvent(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            json_msg,
        )

    async def consumeEvent(self, channel_name, callback_function):
        vlog.info(f"RMQ_HANDLER: Consuming event from queue")
        await consume.consumeEvent(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            callback_function,
        )

    async def listenEvent(self, channel_name, callback_function):
        vlog.info(f"RMQ_HANDLER: Listening for events on pub/sub topic")
        await listen.listenEvent(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            callback_function,
        )

    async def returnQueueMessage(self, channel_name, message_cnt, timeout):
        vlog.info(f"RMQ_HANDLER: Retreiving events to return form queue")
        result = await queue.returnQueueMessage(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            message_cnt,
            timeout,
        )
        return result

    async def returnTopicMessage(self, channel_name, message_cnt, timeout):
        vlog.info(f"RMQ_HANDLER: Retreiving events to return form topic")
        result = await topic.returnTopicMessage(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            message_cnt,
            timeout,
        )
        return result

    async def sendRequest(self, channel_name, timeout, json_msg):
        vlog.info(f"RMQ_HANDLER: Sending request and awaiting response...")
        response = await request.sendRequest(
            self.connection_string,
            channel_name,
            timeout,
            json_msg,
        )
        return response

    async def monitorRequests(self, channel_name, callback_function):
        vlog.info(f"RMQ_HANDLER: Begining monitoring of channel {channel_name} for requests")
        await monitor.monitorRequests(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            callback_function,
        )

    async def joinSubscriberGroup(self, channel_name, subscriber_group_name, callback_function):
        vlog.info(f"RMQ_HANDLER: Joining subscriber group: {subscriber_group_name} on channel {channel_name}")
        await group.joinGroup(
            pika.BlockingConnection(pika.ConnectionParameters(self.connection_string)),
            channel_name,
            subscriber_group_name,
            callback_function,
        )
