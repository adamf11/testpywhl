#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

# Communication channel definitions
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)


class channels:

    objectDomains = [
        "Deployment",
        "XFormer",
        "XFormerPipeline",
        "Model",
    ]

    domainChannels = [
        # Deployment
        "Deployment.PreProcessing",
        "Deployment.Build",
        "Deployment.Register",
        "Deployment.Deploy",
        "Deployment.Predict",
        "Deployment.Predict.Tracking",
        "Deployment.Preprocessing.Notify",
        "Deployment.Build.Notify",
        "Deployment.Register.Notify",
        "Deployment.Deploy.Notify",
        "Deployment.Predict.Notify",
        "Deployment.Predict.Tracking.Notify",
        # XFormer
        "XFormer.Get",
        "XFormer.Save",
        "XFormer.Delete",
        "XFormer.Update",
        "XFormer.Get.Notify",
        "XFormer.Save.Notify",
        "XFormer.Delete.Notify",
        "XFormer.Update.Notify",
        # XFormerPipeline
        "XFormerPipeline.Get",
        "XFormerPipeline.Save",
        "XFormerPipeline.Delete",
        "XFormerPipeline.Update",
        "XFormerPipeline.Get.Notify",
        "XFormerPipeline.Save.Notify",
        "XFormerPipeline.Delete.Notify",
        "XFormerPipeline.Update.Notify",
        # Model
        "Model.Import",
        "Model.Train",
        "Model.Optimize",
        "Model.Benchmark",
        "Model.Save",
        "Model.Update",
        "Model.Delete",
        "Model.Register",
        "Model.XFormerPipeline.Attach",
        "Model.XFormerPipeline.Remove",
        "Model.Import.Notify",
        "Model.Train.Notify",
        "Model.Optimize.Notify",
        "Model.Benchmark.Notify",
        "Model.Save.Notify",
        "Model.Update.Notify",
        "Model.Delete.Notify",
        "Model.Register.Notify",
        "Model.XFormerPipeline.Attach.Notify",
        "Model.XFormerPipeline.Remove.Notify",
    ]

    def checkInternal(name):
        if name in channels.domainChannels:
            return True
        return False
