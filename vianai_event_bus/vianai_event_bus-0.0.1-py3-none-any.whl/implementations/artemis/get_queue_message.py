#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "STOP"


async def returnQueueMessage(artemis_connection, topic_name, message_cnt, timeout):
    vlog.info(f"IMPLEMENTATIONS:ARTEMIS:RETURN_TOPIC_MESSAGE: listenEvent")
    try:
        artemis_connection.subscribe(topic_name, headers={})
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:RETURN_TOPIC_MESSAGE: artemis subscription error:",
            exc_info=True,
        )
        raise ex
    try:
        result = await reader(artemis_connection, message_cnt, timeout)
        artemis_connection.unsubscribe()
        return result
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:RETURN_TOPIC_MESSAGE: artemis listen process failed to start:",
            exc_info=True,
        )


async def reader(listener, message_cnt, timeout):
    messages = []
    try:
        for message in listener.message_list:
            listener.ack('',message)
            if message == STOPWORD:
                break
            pass
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:RETURN_TOPIC_MESSAGE: artemis reader task creation error:",
            exc_info=True,
        )
        raise ex
    return messages