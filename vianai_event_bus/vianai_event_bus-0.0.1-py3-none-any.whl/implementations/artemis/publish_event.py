#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#


import logging
import stomp

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)


async def publishEvent(channel_name, connection_string, connection_port, json_msg):
    vlog.info(f"IMPLEMENTATIONS:ARTEMIS:PUBLISH_EVENT: publishEvent")
    try:
        artemis_connection = stomp.Connection(
            [(connection_string, connection_port)]
        )
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:PUBLISH_EVENT: connection object creation error:",
            exc_info=True,
        )
        raise ex
    try:
        artemis_connection.connect('artemis', 'artemis', wait=True, headers={
                    'client-id': 'vianai-artemis-publish'})
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:PUBLISH_EVENT: Connection call error:",
            exc_info=True,
        )
        raise ex
    try:
        artemis_connection.begin()
        destination = f'/topic/{channel_name}'
        headers = {"persistent": "false", "destination-type":"MULTICAST"}
        artemis_connection.send(
            destination,
            json_msg,
            headers=headers)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:PUBLISH_EVENT: artemis publish event error:",
            ex
        )
    artemis_connection.disconnect()
