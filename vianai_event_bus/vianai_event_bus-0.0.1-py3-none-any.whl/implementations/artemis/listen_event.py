#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import stomp
import logging
import uuid
import multiprocessing

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = 'stop'
subscription_id = ''
destination = ''


class Listener(stomp.ConnectionListener):
    def __init__(self, callback, connection):
        self.callback = callback
        self.connection = connection

    def on_message(self, frame):
        #print(f"Topic Message.Header: {frame.headers}\n")
        #print(f"Topic Message.Body: {frame.body}\n")

        if str(frame.body).lower() == STOPWORD:
            self.connection.unsubscribe(id=subscription_id)
            self.connection.disconnect()
            vlog.info(f"IMPLEMENTATIONS:ARTEMIS:CONSUME_EVENT: reader BREAK")
            print(f"IMPLEMENTATIONS:ARTEMIS:CONSUME_EVENT: reader BREAK")
        else:
            self.callback(frame.body)

    # def on_connecting(self, frame):
    #     print(f'on_connecting: {frame}\n')

    # def on_send(self, frame):
    #     print(f'on_send: {frame}\n')
    
    def on_disconnected(self):
        print(f'on_disconnected: Disconnected\n')
        #connect_and_subscribe(self.conn)


def connect_and_subscribe(conn):
    conn.connect('guest', 'guest', wait=True)
    conn.subscribe(destination=destination , id=subscription_id, ack='auto')


async def listenEvent(channel_name, connection_string, connection_port, callback_function):
    vlog.info(f"IMPLEMENTATIONS:ARTEMIS:LISTEN_EVENT: consumeEvent")
    try:
        reader(channel_name, connection_string,connection_port, callback_function)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:LISTEN_EVENT: artemis reader process creation error:",
            exc_info=True,
        )
        raise ex


def reader(channel_name, connection_string, connection_port, callback_function):
    subscription_id = str(uuid.uuid4())

    try:
        artemis_connection = stomp.Connection([(connection_string, connection_port)])
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:CONSUME_EVENT: connection object creation error:",
            exc_info=True,
        )
        raise ex
    try:
        artemis_connection.set_listener('', Listener(callback_function, artemis_connection))
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:CONSUME_EVENT: Set listener error:",
            exc_info=True,
        )
        raise ex
    try:
        artemis_connection.connect('artemis', 'artemis', wait=True, headers={'client-id': f'vianai-artemis-listen-{subscription_id}'})
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:CONSUME_EVENT: Connection call error:",
            exc_info=True,
        )
        raise ex
    try:
        artemis_connection.subscribe(
            destination=f'/topic/{channel_name}', id=subscription_id, ack='auto',
            headers={'subscription-type': 'MULTICAST',
                     'durable-subscription-name': f'/topic/{channel_name}'}
        )
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:ARTEMIS:CONSUME_EVENT: Subscription error:",
            exc_info=True,
        )
        raise ex
