#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import time
import multiprocessing
import uuid
import json

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"


async def sendRequest(rmq_connection, channel_name, timeout, json_msg):
    correllation_id = str(uuid.uuid4())
    vlog.info(f"IMPLEMENTATIONS:ARTEMIS:SEND_REQUEST: sendRequest called")
    raise NotImplementedError
