#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import multiprocessing
import json

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []

async def joinGroup(rmq_connection, channel_name, subscriber_group_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:ARTEMIS:JOIN_GROUP: joinGroup - NOT IMPLEMENTED")   

# Create a 'reader' as per normal 'consumer' functionality

# Within reader, messages must first go to a 'multicast' queue name=channel_name
#  Then messages must be routed from the first mulitcast queue to an 'anycast' queue name=subscriber_group_name

# Reader will consume messages from the queue name=subscriber_group_name

# Our nested callback will then be triggered for any messages that the reader sees per the 'normal' consume functionality.
