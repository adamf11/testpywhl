#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import multiprocessing
import json

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []


async def monitorRequests(rmq_connection, channel_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:ARTEMIS:MONITOR_REQUESTS: monitorRequest called")
    raise NotImplementedError
