#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import redis

# from .....vlogger.src.vlogging import vlogging
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "STOP"

# vlog = vlogging.vlogging


async def publishEvent(redis_pool, channel_name, json_msg_string):
    vlog.info(f"IMPLEMENTATIONS:REDIS:PUBLISH_EVENT: publishEvent method call")
    try:
        conn = redis.Redis(connection_pool=redis_pool)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:PUBLISH_EVENT: redis conection error:",
            exc_info=True,
        )
        raise ex
    try:
        conn.publish(channel_name, json_msg_string)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:PUBLISH_EVENT: redis publish error:", exc_info=True
        )
        raise ex
