#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

# Redis specific implementation of event_bus communications channel auto management, IE queues and topics

import logging
from vianai_event_bus.src.implementations.channels import channels


vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)
