#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []

async def joinGroup(rmq_connection, channel_name, subscriber_group_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:REDIS:JOIN_GROUP: joinGroup - NOT IMPLEMENTED")   

