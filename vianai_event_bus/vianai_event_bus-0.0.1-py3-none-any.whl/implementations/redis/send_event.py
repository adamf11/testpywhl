#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import redis

# from .....vlogger.src.vlogging import vlogging
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "STOP"

# vlog = vlogging.vlogging


async def sendEvent(redis_pool, channel_name, json_msg):
    vlog.info(f"IMPLEMENTATIONS:REDIS:SEND_EVENT: sendEvent")
    try:
        conn = redis.Redis(connection_pool=redis_pool)
        vlog.info(f"IMPLEMENTATIONS:REDIS:SEND_EVENT: Connected to redis")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:SEND_EVENT: Failed to connect to redis",
            exc_info=True,
        )
        raise ex
    try:
        conn.lpush(channel_name, json_msg)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:SEND_EVENT: redis rpush error:", exc_info=True
        )
        raise ex
