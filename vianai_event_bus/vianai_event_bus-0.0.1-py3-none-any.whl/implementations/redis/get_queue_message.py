#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import redis
import time
import logging
import time

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"


async def returnQueueMessage(redis_pool, channel_name, message_cnt, timeout):
    vlog.info(f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: consumeEvent")
    try:
        conn_p = redis.Redis(connection_pool=redis_pool)
        vlog.info(f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: Connected to redis")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: Failed to connect to redis",
            exc_info=True,
        )
        raise ex
    try:
        result = await reader(conn_p, channel_name, message_cnt, timeout)
        conn_p.close()
        return result
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: redis reader task creation error:",
            exc_info=True,
        )
        raise ex


async def reader(conn_p: redis.Redis, channel_name: str, message_cnt, timeout):
    messages = []
    start_time = time.time()
    while True:
        try:
            msg = conn_p.rpop(channel_name)
            if msg is not None:
                messages.append(msg)
                print(f"Message: {msg} added to the return message list!")
                if len(messages) == message_cnt:
                    vlog.info(
                        f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: All required messages have been received, stopping"
                    )
                    print("All messages read from count, stopping.")
                    break
                if str(msg).lower() == STOPWORD:
                    vlog.info(
                        f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: STOP message received while trying to read messages to return, stopping"
                    )
                    print("Stopword encountered")
                    break
            if (timeout > 0) and (time.time() - start_time) > timeout:
                vlog.info(
                    f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: Message retreival has timed out based on user timeout, stopping."
                )
                print("User timeout hit")
                break
        except Exception as ex:
            vlog.error(
                f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: Exception occured while attempting to get messages from queue:",
                exc_info=True,
            )
            raise ex
    return messages
