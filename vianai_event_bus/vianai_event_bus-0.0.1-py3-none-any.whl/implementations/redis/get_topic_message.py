#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import redis
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"


async def returnTopicMessage(redis_pool, channel_name, message_cnt, timeout):
    vlog.info(f"IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: listenEvent")
    try:
        conn_r = redis.Redis(connection_pool=redis_pool)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: redis connection error:",
            exc_info=True,
        )
        raise ex
    try:
        conn_p = conn_r.pubsub()
        conn_p.subscribe(channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: redis subscription error:",
            exc_info=True,
        )
        raise ex
    try:
        result = await reader(conn_p, message_cnt, timeout)
        conn_p.unsubscribe()
        return result
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: redis listen process failed to start:",
            exc_info=True,
        )


async def reader(conn_p, message_cnt, timeout):
    messages = []
    # start_time = time.time()
    try:
        for message in conn_p.listen():
            msg = message["data"]
            if msg is not None:
                messages.append(msg)
                if len(messages) == message_cnt:
                    vlog.info(
                        f"IMPLEMENTATIONS:REDIS:RETURN_QUEUE_MESSAGE: All required messages have been received"
                    )
                    break
                if str(msg).lower() == STOPWORD:
                    vlog.info(
                        f"IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: STOP message received while trying to read messages to return."
                    )
                    break
            # This can't work right because listen() is blocking, need to revisit
            # if (timeout > 0) and (time.time() - start_time) > timeout:
            #     vlog.info(f'IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: Message retreival has timed out based on user timeout, stopping.')
            #     break
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:RETURN_TOPIC_MESSAGE: redis reader task creation error:",
            exc_info=True,
        )
        raise ex
    return messages
