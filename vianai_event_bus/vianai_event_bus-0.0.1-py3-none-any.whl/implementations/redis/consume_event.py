#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import redis
import time

# from .....vlogger.src.vlogging import vlogging
import logging
import multiprocessing

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)


STOPWORD = "stop"

# vlog = vlogging.vlogging


async def consumeEvent(redis_pool, channel_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:REDIS:CONSUME_EVENT: consumeEvent")
    try:
        conn_p = redis.Redis(connection_pool=redis_pool)
        vlog.info(f"IMPLEMENTATIONS:REDIS:CONSUME_EVENT: Connected to redis")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:CONSUME_EVENT: Failed to connect to redis",
            exc_info=True,
        )
        raise ex
    try:
        listen_process = multiprocessing.Process(
            target=reader,
            args=(
                conn_p,
                channel_name,
                callback_function,
            ),
        )
        listen_process.start()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:CONSUME_EVENT: redis reader task creation error:",
            exc_info=True,
        )
        raise ex


def reader(conn_p: redis.Redis, channel_name: str, callback_function):
    while True:
        try:
            msg = conn_p.rpop(channel_name)
            if str(msg).lower() == STOPWORD:
                conn_p.close()
                vlog.info(f"IMPLEMENTATIONS:REDIS:CONSUME_EVENT: reader BREAK")
                print(f"REDIS MESSAGE CONSUMER STOPPED!")
                break
            if msg is None:
                time.sleep(0.1)  # Necessary evil till I figure out something better
                continue
            callback_function(msg)
        except Exception as ex:
            vlog.error(
                f"IMPLEMENTATIONS:REDIS:CONSUME_EVENT: reader timeout error:",
                exc_info=True,
            )
            raise ex
