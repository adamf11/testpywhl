#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import redis

# from .....vlogger.src.vlogging import vlogging
import logging
import multiprocessing

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

# vlog = vlogging.vlogging


async def listenEvent(redis_pool, channel_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: listenEvent")
    try:
        conn_r = redis.Redis(connection_pool=redis_pool)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: redis connection error:",
            exc_info=True,
        )
        raise ex

    try:
        conn_p = conn_r.pubsub()
        conn_p.subscribe(channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: redis subscription error:",
            exc_info=True,
        )
        raise ex

    try:
        listen_process = multiprocessing.Process(
            target=reader,
            args=(
                conn_p,
                callback_function,
            ),
        )
        listen_process.start()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: redis listen process failed to start:",
            exc_info=True,
        )


def reader(conn_p, callback_function):
    vlog.info(f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: reader")
    try:
        for message in conn_p.listen():
            msg = message["data"]
            if msg is not None:
                if str(msg).lower() == STOPWORD:
                    conn_p.unsubscribe()
                    vlog.info(f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: reader BREAK")
                    print(f"REDIS LISTEN READER STOPPED!")
                    break
                callback_function(msg)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:REDIS:LISTEN_EVENT: redis reader task creation error:",
            exc_info=True,
        )
        raise ex
