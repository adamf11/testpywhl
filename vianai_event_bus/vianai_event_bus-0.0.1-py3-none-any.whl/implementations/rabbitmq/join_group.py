#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import multiprocessing
import json

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []

# This functionality joins a call_back to a subscription group, and consumes messages similarly
#  to the standard "consumeEvent" functionality
async def joinGroup(rmq_connection, channel_name, subscriber_group_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: joinGroup")
    global user_callback
    user_callback = callback_function
    try:
        consume_process = multiprocessing.Process(
            target=reader,
            args=(
                rmq_connection,
                channel_name,
                subscriber_group_name,
            ),
        )
        consume_process.start()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq reader task creation error:",
            exc_info=True,
        )
        raise ex


def reader(rmq_connection, channel_name, subscriber_group_name):
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq channel creation error channel={channel_name}:",
            exc_info=True,
        )
        raise ex
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq exchange declare error for exchange=general:",
            exc_info=True,
        )
    try:
        channel.exchange_declare(exchange=channel_name, exchange_type="fanout")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq exchange declare error for exchange={channel_name}:",
            exc_info=True,
        )
    try:
        channel.exchange_bind(destination=channel_name, source="general", routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq channel exchange_bind error destination={channel_name} source=general:",
            exc_info=True,
        )
    try:
        result = channel.queue_declare(queue=subscriber_group_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq queue_declare error queue={subscriber_group_name}:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_bind(exchange=channel_name, queue=subscriber_group_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq queue_bind error exchange={channel_name} queue={subscriber_group_name}:",
            exc_info=True,
        )
        raise ex
    try:
        channel.basic_consume(
            queue=subscriber_group_name,
            auto_ack=False,
            on_message_callback=nestedCallbackFunction,
        )
        channel.start_consuming()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP: rabbitmq consume error:",
            exc_info=True,
        )
        raise ex


def nestedCallbackFunction(ch, method, properties, body):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP:NESTED_CALLBACK_FUNCTION: Library callback wrapper called."
    )
    if body.decode().lower() == STOPWORD:
        vlog.info(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP:NESTED_CALLBACK_FUNCTION: reader BREAK"
        )
        ch.basic_ack(delivery_tag=method.delivery_tag)
        ch.stop_consuming()
        ch.close()
        return
    json_body = []
    try:
        json_body = json.loads(body)
    except json.JSONDecodeError as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP:NESTED_CALLBACK_FUNCTION: Message body was malformed:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
        return
    try:
        user_callback(json_body)
        ch.basic_ack(delivery_tag=method.delivery_tag)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:JOIN_GROUP:NESTED_CALLBACK_FUNCTION: User provided callback raised exception:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

