#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

# RabbitMQ specific implementation of event_bus communications channel auto management, IE queues and topics
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)
