#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import multiprocessing
import json

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []


async def consumeEvent(rmq_connection, channel_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: consumeEvent")
    global user_callback
    user_callback = callback_function
    try:
        consume_process = multiprocessing.Process(
            target=reader,
            args=(
                rmq_connection,
                channel_name,
            ),
        )
        consume_process.start()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: rabbitmq reader task creation error:",
            exc_info=True,
        )
        raise ex


def reader(rmq_connection, channel_name):
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: rabbitmq channel exchange_declare error:",
            exc_info=True,
        )
    try:
        channel.queue_declare(queue=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_bind(exchange="general", queue=channel_name, routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: rabbitmq channel queue_bind error:",
            exc_info=True,
        )
    try:
        channel.basic_consume(
            queue=channel_name,
            auto_ack=False,
            on_message_callback=nestedCallbackFunction,
        )
        channel.start_consuming()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT: rabbitmq consume error:",
            exc_info=True,
        )
        raise ex


# Wrap the event system library user provided callback function to abstract
#  the RabbitMQ specific mechanics of a callback
def nestedCallbackFunction(ch, method, properties, body):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT:NESTED_CALLBACK_FUNCTION: Library callback wrapper called."
    )
    if body.decode().lower() == STOPWORD:
        vlog.info(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT:NESTED_CALLBACK_FUNCTION: reader BREAK"
        )
        ch.basic_ack(delivery_tag=method.delivery_tag)
        ch.close()
        return
    json_body = []
    try:
        json_body = json.loads(body)
    except json.JSONDecodeError as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT:NESTED_CALLBACK_FUNCTION: Message body was malformed:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
        return
    try:
        user_callback(json_body)
        ch.basic_ack(delivery_tag=method.delivery_tag)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:CONSUME_EVENT:NESTED_CALLBACK_FUNCTION: User provided callback raised exception:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
