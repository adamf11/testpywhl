#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import multiprocessing
import json

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []


async def listenEvent(rmq_connection, channel_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: listenEvent")
    global user_callback
    user_callback = callback_function
    try:
        consume_process = multiprocessing.Process(
            target=reader,
            args=(
                rmq_connection,
                channel_name,
            ),
        )
        consume_process.start()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: redis reader task creation error:",
            exc_info=True,
        )
        raise ex


def reader(rmq_connection, channel_name):
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq channel exchange_declare error:",
            exc_info=True,
        )
    try:
        channel.exchange_declare(exchange=channel_name, exchange_type="fanout")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq exchange declare error:",
            exc_info=True,
        )
    try:
        channel.exchange_bind(destination=channel_name, source="general", routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq channel exchange_bind error:",
            exc_info=True,
        )
    try:
        result = channel.queue_declare(queue="", exclusive=True)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_bind(exchange=channel_name, queue=result.method.queue)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq queue_bind error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.basic_consume(
            queue=result.method.queue,
            auto_ack=False,
            on_message_callback=nestedCallbackFunction,
        )
        channel.start_consuming()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT: rabbitmq consume error:",
            exc_info=True,
        )
        raise ex


# Wrap the event system library user provided callback function to abstract
#  the RabbitMQ specific mechanics of a callback
def nestedCallbackFunction(ch, method, properties, body):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT:NESTED_CALLBACK_FUNCTION: Library callback wrapper called."
    )
    if body.decode().lower() == STOPWORD:
        vlog.info(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT:NESTED_CALLBACK_FUNCTION: reader BREAK"
        )
        ch.basic_ack(delivery_tag=method.delivery_tag)
        ch.close()
        return
    json_body = []
    try:
        json_body = json.loads(body)
    except json.JSONDecodeError as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT:NESTED_CALLBACK_FUNCTION: Message body was malformed:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
        return
    try:
        user_callback(json_body)
        ch.basic_ack(delivery_tag=method.delivery_tag)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:LISTEN_EVENT:NESTED_CALLBACK_FUNCTION: User provided callback raised exception:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
