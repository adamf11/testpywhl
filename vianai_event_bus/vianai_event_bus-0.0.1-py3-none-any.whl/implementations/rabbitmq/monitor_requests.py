#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import multiprocessing
import json
import base64

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"

user_callback = []


async def monitorRequests(rmq_connection, channel_name, callback_function):
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: monitorRequests called")
    global user_callback
    user_callback = callback_function
    try:
        consume_process = multiprocessing.Process(
            target=reader,
            args=(
                rmq_connection,
                channel_name,
            ),
        )
        consume_process.start()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: redis reader task creation error:",
            exc_info=True,
        )
        raise ex


def reader(rmq_connection, channel_name):
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: rabbitmq channel exchange_declare error:",
            exc_info=True,
        )
    try:
        channel.queue_declare(queue=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_bind(exchange="general", queue=channel_name, routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: rabbitmq channel queue_bind error:",
            exc_info=True,
        )
    try:
        channel.basic_consume(
            queue=channel_name,
            auto_ack=False,
            on_message_callback=nestedCallbackFunction,
        )
        channel.start_consuming()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS: rabbitmq consume error:",
            exc_info=True,
        )
        raise ex


# Wrap the event system library user provided callback function to abstract
#  the RabbitMQ specific mechanics of a callback
def nestedCallbackFunction(ch, method, properties, body):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:NESTED_CALLBACK_FUNCTION: Library callback wrapper called."
    )
    if body.decode().lower() == STOPWORD:
        vlog.info(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:NESTED_CALLBACK_FUNCTION: STOPWORD reader BREAK"
        )
        ch.basic_ack(delivery_tag=method.delivery_tag)
        ch.close()
        return
    json_body = []
    try:
        json_body = json.loads(body)
        correllation_id = json_body["correllation_id"]
        nested_body = json_body["body"]

        #Decode original message
        nested_body.encode('ascii')
        message_bytes = base64.b64decode(nested_body)
        message = message_bytes.decode('ascii')

    except json.JSONDecodeError as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:NESTED_CALLBACK_FUNCTION: Message body was malformed:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
        return
    try:
        response_msg = user_callback(message)
        send_response(ch, correllation_id, response_msg)
        ch.basic_ack(delivery_tag=method.delivery_tag)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:NESTED_CALLBACK_FUNCTION: User provided callback raised exception:",
            exc_info=True,
        )
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

def send_response(channel, channel_name, json_msg):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:SEND_RESPONSE: sendResponse started"
    )
    try:
        channel.queue_declare(queue=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:SEND_RESPONSE: rabbitmq channel queue_declare error:",
            exc_info=True,
        )
    try:
        channel.basic_publish(exchange="", routing_key=channel_name, body=json_msg)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:MONITOR_REQUESTS:SEND_RESPONSE: rabbitmq channel publish error:",
            exc_info=True,
        )
