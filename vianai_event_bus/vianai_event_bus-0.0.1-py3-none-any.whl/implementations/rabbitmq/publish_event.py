#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)


async def publishEvent(rmq_connection, channel_name, json_msg):
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:PUBLISH_EVENT: publishEvent called")
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:PUBLISH_EVENT: rabbitmq channel creation error:",
            exc_info=True,
        )
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:PUBLISH_EVENT: rabbitmq channel exchange_declare error:",
            exc_info=True,
        )
    try:
        channel.exchange_declare(exchange=channel_name, exchange_type="fanout")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:PUBLISH_EVENT: rabbitmq exchange declare error:",
            exc_info=True,
        )
    try:
        channel.exchange_bind(destination=channel_name, source="general", routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:PUBLISH_EVENT: rabbitmq channel exchange_bind error:",
            exc_info=True,
        )
    try:
        channel.basic_publish(exchange="general", routing_key=channel_name, body=json_msg)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:PUBLISH_EVENT: rabbitmq channel publish error:",
            exc_info=True,
        )
    rmq_connection.close()
