#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import time
import multiprocessing

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"


async def returnTopicMessage(rmq_connection, channel_name, message_cnt, timeout):
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:RETURN_QUEUE_MESSAGE: consumeEvent")
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq channel exchange_declare error:",
            exc_info=True,
        )
    try:
        channel.exchange_declare(exchange=channel_name, exchange_type="fanout")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq exchange declare error:",
            exc_info=True,
        )
    try:
        channel.exchange_bind(destination=channel_name, source="general", routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq channel exchange_bind error:",
            exc_info=True,
        )
    try:
        result = channel.queue_declare(queue="", exclusive=True)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_bind(exchange=channel_name, queue=result.method.queue)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq queue_bind error:",
            exc_info=True,
        )
        raise ex
    try:
        if timeout > 0:
            timeout_process = multiprocessing.Process(
                target=breakReader,
                args=(
                    channel,
                    result.method.queue,
                    timeout,
                ),
            )
            timeout_process.start()
        messages = await reader(channel, channel_name, message_cnt, timeout)
        if timeout > 0:
            try:
                timeout_process.kill()
                vlog.info(
                    f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: Cleaning up break timer"
                )
            except Exception:
                vlog.info(
                    f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: Cleaning up break timer"
                )
        rmq_connection.close()
        return messages
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq reader task creation error:",
            exc_info=True,
        )
        raise ex


async def reader(channel, channel_name, message_cnt, timeout):
    start_time = time.time()
    messages = []
    try:
        for method_frame, properties, body in channel.consume(channel_name):
            if body is not None:
                messages.append(body.decode())
                channel.basic_ack(method_frame.delivery_tag)
                if len(messages) == message_cnt:
                    vlog.info(
                        f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: All required messages have been received, stopping"
                    )
                    break
                if body.decode().lower() == STOPWORD:
                    vlog.info(
                        f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: STOP message received while trying to read messages to return, stopping"
                    )
                    break
            if (timeout > 0) and (time.time() - start_time) > timeout:
                vlog.info(
                    f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: Message retreival has timed out based on user timeout, stopping."
                )
                break
        channel.cancel()
        channel.close()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE: rabbitmq consume error:",
            exc_info=True,
        )
        raise ex
    return messages


def breakReader(channel, channel_name, timeout):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE:BREAK_READER: breakReader started"
    )
    try:
        time.sleep(timeout)
        channel.basic_publish(exchange="", routing_key=channel_name, body=STOPWORD)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:RETURN_TOPIC_MESSAGE:BREAK_READER: rabbitmq channel publish error:",
            exc_info=True,
        )
