#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import logging
import time
import multiprocessing
import uuid
import json
import base64
import pika

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

STOPWORD = "stop"


async def sendRequest(connection_string, channel_name, timeout, json_msg):
    correllation_id = str(uuid.uuid4())
    vlog.info(f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: sendRequest called")

    await sendRequestMsg(connection_string, channel_name, json_msg, correllation_id)

    ## Start the timeout process
    try:
        if timeout > 0:
            timeout_process = multiprocessing.Process(
                target=breakReader,
                args=(
                    connection_string,
                    correllation_id,
                    timeout,
                ),
            )
            timeout_process.start()

        ## Start the response listener
        response = await reader(connection_string, correllation_id)

        ## Clean up the timeout process
        if timeout > 0:
            try:
                timeout_process.kill()
                vlog.info(
                    f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: Cleaning up break timer"
                )
            except Exception:
                vlog.info(
                    f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: Cleaning up break timer"
                )

        return response
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq reader task creation error:",
            exc_info=True,
        )
        raise ex


async def reader(connection_string, channel_name):
    rmq_connection = pika.BlockingConnection(pika.ConnectionParameters(connection_string))
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_declare(queue=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    message = ''
    try:
        while True:
            method_frame, header_frame, body = channel.basic_get(channel_name)
            if body is not None:
                message = body.decode()
                channel.basic_ack(method_frame.delivery_tag)
                if body.decode().lower() == STOPWORD:
                    vlog.info(
                        f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: STOP message received while trying to read response message to return, timeout reached, stopping"
                    )
                    message = "ERROR: Timeout reached and no response was received"
                break
            time.sleep(0.1)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq consume error:",
            exc_info=True,
        )
        raise ex
    channel.queue_delete(queue=channel_name)
    channel.close()
    rmq_connection.close()
    return message


def breakReader(connection_string, channel_name, timeout):
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST:BREAK_READER: breakReader started"
    )
    rmq_connection = pika.BlockingConnection(pika.ConnectionParameters(connection_string))
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_declare(queue=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    try:
        time.sleep(timeout)
        channel.basic_publish(exchange="", routing_key=channel_name, body=STOPWORD)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST:BREAK_READER: rabbitmq channel publish error:",
            exc_info=True,
        )
    channel.close()
    rmq_connection.close()



async def sendRequestMsg(connection_string, channel_name, json_msg, correllation_id):
    message_bytes = str(json_msg).encode('ascii')
    base64_msg = base64.b64encode(message_bytes)
    message_string = base64_msg.decode('ascii')
    msg = '{"correllation_id":'+'"'+str(correllation_id)+'"'+', "body":'+'"'+str(message_string)+'"}'
    vlog.info(
        f"IMPLEMENTATIONS:RABBITMQ:REQUEST:SEND_REQUEST: sendRequest started"
    )
    rmq_connection = pika.BlockingConnection(pika.ConnectionParameters(connection_string))
    try:
        channel = rmq_connection.channel()
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq channel creation error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.exchange_declare(exchange="general", exchange_type="topic")
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq channel exchange_declare error:",
            exc_info=True,
        )
    try:
        channel.queue_declare(queue=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq queue_declare error:",
            exc_info=True,
        )
        raise ex
    try:
        channel.queue_bind(exchange="general", queue=channel_name, routing_key=channel_name)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:SEND_REQUEST: rabbitmq channel queue_bind error:",
            exc_info=True,
        )
    try:
        channel.basic_publish(exchange="general", routing_key=channel_name, body=msg)
    except Exception as ex:
        vlog.error(
            f"IMPLEMENTATIONS:RABBITMQ:REQUEST:SEND_REQUEST: rabbitmq channel publish error:",
            exc_info=True,
        )
    channel.close()
    rmq_connection.close()
