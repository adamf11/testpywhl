#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

from sys import exc_info
from redis_handler import redis_handler
from rabbitmq_handler import rabbitmq_handler
from artemis_handler import artemis_handler
import aiohttp
import asyncio
import json
import logging
from vianai_messenger_utils import channel_types, is_name_wildcard
from enum import Enum

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)


class vianai_messenger:
    connection_port = 0
    connection_string = ""
    protocol_handler = ""
    channel_name = ""

    def __init__(self):
        vlog.info(f"VIANAI_MESSENGER: __init__")

    # Syncronous wrapper for set configs
    def setConfigsSync(self, config_name, access_token, channel_type_enum):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.setConfigsAsync(config_name, access_token, channel_type_enum)
        )
        loop.run_until_complete(task)

    async def setConfigsAsync(self, config_name, access_token, channel_type_enum):
        vlog.info(f"VIANAI_MESSENGER: set_configs")

        channel_type = channel_types(channel_type_enum).value

        # Get config info
        try:
            connection_configs_return = await get_connection_data(access_token)
            connection_config_return_json = json.loads(connection_configs_return)
            connection_config_string = connection_config_return_json["value"]
            connection_config_json = json.loads(connection_config_string)
        except Exception as ex:
            vlog.error(
                f"VIANAI_MESSENGER: Error occured when attempting to retrieve the connection configuration information",
                exc_info=True,
            )
            raise ex

        try:
            event_configs = await get_event_lookup_data(access_token)
            event_configs_return_json = json.loads(event_configs)
            event_configs_string = event_configs_return_json["value"]
            events_json = json.loads(event_configs_string)
        except Exception as ex:
            vlog.error(
                f"VIANAI_MESSENGER: Error occured when attempting to retrieve the event type configuration information",
                exc_info=True,
            )
            raise ex

        try:
            protocol_configs = await get_protocol_lookup_data(access_token)
            protocol_configs_return_json = json.loads(protocol_configs)
            protocol_configs_string = protocol_configs_return_json["value"]
            protocols_json = json.loads(protocol_configs_string)
        except Exception as ex:
            vlog.error(
                f"VIANAI_MESSENGER: Error occured when attempting to retrieve the protocol type configuration information",
                exc_info=True,
            )
            raise ex

        # Set connection info
        self.connection_string = connection_config_json["message_bus_connection"][
            "connection_string"
        ]
        self.connection_port = connection_config_json["message_bus_connection"][
            "connection_port"
        ]

        # Dynamically create the proper message handler
        protocol_id = connection_config_json["message_bus_connection"]["protocol_type"]
        protocol_name = f"{protocols_json[str(protocol_id)]}_handler"
        constructor = globals()[protocol_name]
        self.protocol_handler = constructor(
            self.connection_string, self.connection_port
        )

        # get channel name for comm
        self.channel_name = await get_channel_name(
            access_token, config_name, channel_type
        )

    # Create an event on a message queue
    async def sendEventAsync(self, json_msg):
        vlog.info(f"VIANAI_MESSENGER: Create event message on event queue")
        await self.protocol_handler.sendEvent(self.channel_name, json_msg)

    def sendEventSync(self, json_msg):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.sendEvent(self.channel_name, json_msg)
        )
        loop.run_until_complete(task)

    # Publish a message on a pub/sub channel
    async def publishEventAsync(self, json_msg):
        vlog.info(f"VIANAI_MESSENGER: Publishing event message to pubsub topic")
        await self.protocol_handler.publishEvent(self.channel_name, json_msg)

    def publishEventSync(self, json_msg):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.publishEvent(self.channel_name, json_msg)
        )
        loop.run_until_complete(task)

    # Consume an event off a message queue
    async def consumeEventAsync(self, callback_function):
        vlog.info(f"VIANAI_MESSENGER: Consuming events from an event queue")
        await self.protocol_handler.consumeEvent(self.channel_name, callback_function)

    def consumeEventSync(self, callback_function):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.consumeEvent(self.channel_name, callback_function)
        )
        loop.run_until_complete(task)

    # Subscribe to a pub/sub channel
    async def listenEventAsync(self, callback_function):
        vlog.info(f"VIANAI_MESSENGER: Listening to a topic for events on that topic")
        await self.protocol_handler.listenEvent(self.channel_name, callback_function)

    def listenEventSync(self, callback_function):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.listenEvent(self.channel_name, callback_function)
        )
        loop.run_until_complete(task)

    # Return a set number of queue messages with optional timeout in seconds
    async def returnQueueMessageAsync(self, message_cnt=1, timeout=0):
        vlog.info(f"VIANAI_MESSENGER: Retreiving message from queue")
        result = await self.protocol_handler.returnQueueMessage(
            self.channel_name, message_cnt, timeout
        )
        return result

    def returnQueueMessageSync(self, message_cnt=1, timeout=0):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.returnQueueMessageAsync(message_cnt, timeout)
        )
        loop.run_until_complete(task)
        return task.result()

    # Return a set number of topic message with optional timeout in seconds
    async def returnTopicMessageAsync(self, message_cnt=1, timeout=0):
        vlog.info(f"VIANAI_MESSENGER: Retreiving message from topic")
        result = await self.protocol_handler.returnTopicMessage(
            self.channel_name, message_cnt, timeout
        )
        return result

    def returnTopicMessageSync(self, message_cnt=1, timeout=0):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.returnTopicMessageAsync(message_cnt, timeout)
        )
        loop.run_until_complete(task)
        return task.result()

    # Send a request message and await a response message with a timeout
    async def sendRequestAsync(self, json_msg, timeout=0):
        vlog.info(f"VIANAI_MESSENGER: Sending request message and waiting response")
        result = await self.protocol_handler.sendRequest(
            self.channel_name, timeout, json_msg
        )
        return result

    def sendRequestSync(self, json_msg, timeout=0):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.sendRequest(self.channel_name, timeout, json_msg)
        )
        loop.run_until_complete(task)
        return task.result()

    # Monitor for, and send responses to, request messages
    async def monitorRequestsAsync(self, callback_function):
        vlog.info(f"VIANAI_MESSENGER: Monitoring for request messages...")
        result = await self.protocol_handler.monitorRequests(
            self.channel_name, callback_function
        )
        return result

    def monitorRequestsSync(self, callback_function):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.monitorRequests(self.channel_name, callback_function)
        )
        loop.run_until_complete(task)
        return task.result()

    # Create a joinable subscriber group
    async def createSubscriberGroupAsync(self, channel_name, subscriber_group_name):
        vlog.info(f"VIANAI_MESSENGER: Creating a new subscriber group")


    async def joinSubscriberGroupAsync(self, subscriber_group_name, callback_function):
        vlog.info(f"VIANAI_MESSENGER: Joining a subscriber group")
        await self.protocol_handler.joinSubscriberGroup(self.channel_name, subscriber_group_name, callback_function)


    def joinSubscriberGroupSync(self, subscriber_group_name, callback_function):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            self.protocol_handler.joinSubscriberGroupAsync(subscriber_group_name, callback_function)
        )
        loop.run_until_complete(task)


    # Auto manage channels (this endpoint is like manually calling garbage collection)
    async def ensureChannelAsync(access_token, config_name, channel_type):
        channel_name = await get_channel_name(access_token, config_name, channel_type)
        vlog.info(f'Channel "{channel_name}" exists or has been created!')

    def ensureChannelSync(access_token, config_name, channel_type):
        loop = asyncio.get_event_loop()
        task = loop.create_task(
            get_channel_name(access_token, config_name, channel_type)
        )
        loop.run_until_complete(task)
        channel_name = task.result()
        vlog.info(f'Channel "{channel_name}" exists or has been created!')


async def get_connection_data(access_token):
    library_config_name = (
        "message_bus_connection_dev"  # This needs to be in environment
    )
    vlog.info(f"VIANAI_MESSENGER: Getting config info")
    # sslcontext = ssl.create_default_context()
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(trust_env=True) as session:
        if str(access_token).lower() == "local":
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={library_config_name}"
            ) as response:
                resp = await response.text()
                return await response.text()
        else:
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={library_config_name}",
                headers=headers,
                ssl=True,
            ) as response:
                return await response.text()


async def get_channel_name(access_token, config_name, channel_type):
    if await is_name_wildcard(config_name):
        return config_name
    try:
        channel_configs_return = await get_channel_mappings_data(access_token)
        channel_configs_return_json = json.loads(channel_configs_return)
        channel_configs_string = channel_configs_return_json["value"]
        channel_configs_fixed_string = str(channel_configs_string).replace("'", '"')
        channel_mappings_json = json.loads(channel_configs_fixed_string)
    except Exception as ex:
        vlog.error(
            f"VIANAI_MESSENGER: Error occured when attempting to retrieve the event channel configuration information",
            exc_info=True,
        )
        raise ex
    channel_name = "UNKNOWN"
    for item in channel_mappings_json["event_channel_mappings"]:
        if str.lower(item["name"]) == str.lower(config_name):
            channel_name = item["channel_name"]
    if channel_name == "UNKNOWN":
        try:
            # Add the channel with default configs using provided channel_type to the database.
            config_to_add = (
                "{'module':'user_created', 'name':'"
                + config_name
                + "', 'type':'"
                + str(channel_type)
                + "', 'channel_name':'"
                + config_name
                + "', 'delay_delivery':'false', 'delay_time':'0', 'durable':'true', 'ttl':'0', 'ignore_deadletter':'true'}"
            )
            event_channel_mappings = channel_mappings_json["event_channel_mappings"]
            event_channel_mappings_cleaned = str(event_channel_mappings).strip("[]")
            appended_config = (
                "{'event_channel_mappings':["
                + event_channel_mappings_cleaned
                + ", "
                + str(config_to_add)
                + "]}"
            )
            full_config_object = (
                '{"system":"vianai", "module":"platform_api", "name":"event_channel_mappings", "value":"'
                + appended_config
                + '"}'
            )

            response = await set_channel_mappings_data(access_token, full_config_object)
            vlog.info(f"VIANAI_MESSENGER: Channel configs saved via API: {response}")

            channel_name = config_name
        except Exception as ex:
            vlog.error(
                f'ERROR: VIANAI_MESSENGER: No DB configuration found for config_name: "{config_name}" and creation of the channel config failed!',
                exc_info=True,
            )
            raise Exception(
                f'ERROR: VIANAI_MESSENGER: No DB configuration found for config_name: "{config_name}" and creation of the channel config failed! : {ex}'
            )
    return channel_name


async def get_channel_mappings_data(access_token):
    library_config_name = "event_channel_mappings"  # This needs to be in environment
    vlog.info(f"VIANAI_MESSENGER: Getting config info")
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(trust_env=True) as session:
        if str(access_token).lower() == "local":
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={library_config_name}"
            ) as response:
                resp = await response.text()
                return await response.text()
        else:
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={library_config_name}",
                headers=headers,
                ssl=True,
            ) as response:
                return await response.text()


async def set_channel_mappings_data(access_token, json_config):
    vlog.info(f"VIANAI_MESSENGER: Setting updated config info")
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(trust_env=True) as session:
        if str(access_token).lower() == "local":
            async with session.post(
                f"http://webservices:5000/v1/vianai_config/setValue", data=json_config
            ) as response:
                resp = await response.text()
                return await response.text()
        else:
            async with session.post(
                f"http://webservices:5000/v1/vianai_config/setValue",
                headers=headers,
                data=json_config,
                ssl=True,
            ) as response:
                return await response.text()


async def get_event_lookup_data(access_token):
    event_types_name = "event_types"  # These need to be in environment
    vlog.info(f"VIANAI_MESSENGER: Getting event lookup info")
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(trust_env=True) as session:
        if str(access_token).lower() == "local":
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={event_types_name}"
            ) as response:
                resp = await response.text()
                return await response.text()
        else:
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={event_types_name}",
                headers=headers,
                ssl=True,
            ) as response:
                return await response.text()


async def get_protocol_lookup_data(access_token):
    protocol_types_name = "protocol_types"
    vlog.info(f"VIANAI_MESSENGER: Getting protocol lookup info")
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(trust_env=True) as session:
        if str(access_token).lower() == "local":
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={protocol_types_name}"
            ) as response:
                resp = await response.text()
                return await response.text()
        else:
            async with session.get(
                f"http://webservices:5000/v1/vianai_config/getValue?system=vianai&module=platform_api&name={protocol_types_name}",
                headers=headers,
                ssl=True,
            ) as response:
                return await response.text()
