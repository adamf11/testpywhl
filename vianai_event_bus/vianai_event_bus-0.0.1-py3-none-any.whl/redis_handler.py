#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import os
from implementations.redis import consume_event as consume
from implementations.redis import listen_event as listen
from implementations.redis import publish_event as publish
from implementations.redis import send_event as send
from implementations.redis import get_queue_message as queue
from implementations.redis import get_topic_message as topic
from implementations.redis import send_request as request
from implementations.redis import monitor_requests as monitor
from implementations.redis import join_group as group
import redis
import logging

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

os.environ["PROJECT_PATH"] = "/"

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")


class redis_handler:
    redis_pool = redis

    # Init Operations
    def __init__(self, connection_string, connection_port):
        vlog.info(f"REDIS_HANDLER: __init__")
        try:
            self.redis_pool = redis.ConnectionPool(
                host=connection_string,
                port=connection_port,
                db=0,
                max_connections=1000,
                decode_responses=True,
            )
        except Exception as ex:
            vlog.error(
                f"REDIS_HANDLER: Creation of redis connection pools failed!",
                exc_info=True,
            )
            raise ex

    def getConnection():
        vlog.info(f"REDIS_HANDLER: Getting connection object")

    def configureRedis():
        vlog.info(f"REDIS_HANDLER: Configuring for vianai messaging system")

    # Primary Functions
    async def sendEvent(self, channel_name, json_msg):
        vlog.info(f"REDIS_HANDLER: Creating event on queue")
        await send.sendEvent(self.redis_pool, channel_name, json_msg)

    async def publishEvent(self, channel_name, json_msg):
        vlog.info(f"REDIS_HANDLER: Publishing event to topic")
        await publish.publishEvent(self.redis_pool, channel_name, json_msg)

    async def consumeEvent(self, channel_name, callback_function):
        vlog.info(f"REDIS_HANDLER: Consuming event from queue")
        await consume.consumeEvent(self.redis_pool, channel_name, callback_function)

    async def listenEvent(self, channel_name, callback_function):
        vlog.info(f"REDIS_HANDLER: Listening for events on pub/sub topic")
        await listen.listenEvent(self.redis_pool, channel_name, callback_function)

    async def returnQueueMessage(self, channel_name, message_cnt, timeout):
        vlog.info(f"REDIS_HANDLER: Retreiving events to return form queue")
        result = await queue.returnQueueMessage(
            self.redis_pool, channel_name, message_cnt, timeout
        )
        return result

    async def returnTopicMessage(self, channel_name, message_cnt, timeout):
        vlog.info(f"REDIS_HANDLER: Retreiving events to return form topic")
        result = await topic.returnTopicMessage(
            self.redis_pool, channel_name, message_cnt, timeout
        )
        return result

    async def sendRequest(self, channel_name, timeout, json_msg):
        vlog.info(f"REDIS_HANDLER: Sending request and awaiting response...")
        response = await request.sendRequest(
            self.redis_pool,
            channel_name,
            timeout,
            json_msg,
        )
        return response

    async def monitorRequests(self, channel_name, callback_function):
        vlog.info(f"REDIS_HANDLER: Begining monitoring of channel {channel_name} for requests")
        await monitor.monitorRequests(
            self.redis_pool,
            channel_name,
            callback_function,
        )

    async def joinSubscriberGroup(self, channel_name, subscriber_group_name, callback_function):
        vlog.info(f"REDIS_HANDLER: Joining subscriber group: {subscriber_group_name} on channel {channel_name}")
        await group.joinGroup(
            self.redis_pool,
            channel_name,
            subscriber_group_name,
            callback_function,
        )
