#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import os
import sys
import logging
from enum import Enum

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)


class channel_types(Enum):
    QUEUE = 1
    TOPIC = 2


async def is_name_wildcard(channel_name):
    if channel_name != None and "*." in channel_name:
        return True
    if channel_name != None and ".*." in channel_name:
        return True
    if channel_name != None and ".*" in channel_name:
        return True
    if channel_name != None and "#." in channel_name:
        return True
    if channel_name != None and ".#." in channel_name:
        return True
    if channel_name != None and ".#" in channel_name:
        return True
    return False