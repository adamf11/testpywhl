#
# Copyright 2021 Vianai Systems, Inc. Vianai Confidential & Proprietary Information
#

import os
import stomp
import logging

from implementations.artemis import send_event as send
from implementations.artemis import listen_event as listen
from implementations.artemis import consume_event as consume
from implementations.artemis import publish_event as publish
from implementations.artemis import get_queue_message as queue
from implementations.artemis import get_topic_message as topic
from implementations.artemis import send_request as request
from implementations.artemis import monitor_requests as monitor
from implementations.artemis import join_group as group

vlog = logging.getLogger("gunicorn.error")
vlog.setLevel(logging.INFO)

os.environ["PROJECT_PATH"] = "/"


class artemis_handler:

    # Init Operations
    def __init__(self, connection_string, connection_port):
        vlog.info(f"ARTEMIS_HANDLER: __init__")
        self.connection_string = connection_string
        self.connection_port = connection_port
        # try:
        #     self.connection = stomp.Connection12(
        #         [(self.connection_string, self.connection_port)]
        #     )
        #     self.connection.connect('artemis', 'artemis', wait=True, headers={
        #                             'client-id': 'vianai-artemis-active-MQ'})
        # except Exception as ex:
        #     vlog.error(
        #         f"ARTEMIS_HANDLER: Error attempting to connect to the Artermis server! \n {ex}",
        #         exc_info=True,
        #     )

    # def getConnection(self):
    #     vlog.info(f"ARTEMIS_HANDLER: Getting connection object")
    #     return self.connection

    # Primary Functions
    async def sendEvent(self, channel_name, json_msg):
        vlog.info(f"ARTEMIS_HANDLER: Creating event on queue")
        await send.sendEvent(channel_name, self.connection_string, self.connection_port, json_msg)

    async def consumeEvent(self, channel_name, callback_function):
        vlog.info(f"ARTEMIS_HANDLER: Consuming event from queue")
        await consume.consumeEvent(channel_name, self.connection_string, self.connection_port, callback_function)

    async def publishEvent(self, channel_name, json_msg):
        vlog.info(f"ARTEMIS_HANDLER: Publishing event to topic")
        await publish.publishEvent(channel_name, self.connection_string, self.connection_port, json_msg)

    async def listenEvent(self, channel_name, callback_function):
        vlog.info(f"ARTEMIS_HANDLER: Listening for events on pub/sub topic")
        await listen.listenEvent(channel_name, self.connection_string, self.connection_port, callback_function)

    async def returnQueueMessage(self, channel_name, message_cnt, timeout):
        vlog.info(f"ARTEMIS_HANDLER: Retreiving events to return form queue")
        result = await queue.returnQueueMessage(channel_name, message_cnt, timeout)
        return result

    async def returnTopicMessage(self, channel_name, message_cnt, timeout):
        vlog.info(f"ARTEMIS_HANDLER: Retreiving events to return form topic")
        result = await topic.returnTopicMessage(channel_name, message_cnt, timeout)
        return result

    async def sendRequest(self, channel_name, timeout, json_msg):
        vlog.info(f"ARTEMIS_HANDLER: Sending request and awaiting response...")
        response = await request.sendRequest(
            self.connection_string,
            self.connection_port,
            channel_name,
            timeout,
            json_msg,
        )
        return response

    async def monitorRequests(self, channel_name, callback_function):
        vlog.info(
            f"ARTEMIS_HANDLER: Begining monitoring of channel {channel_name} for requests")
        await monitor.monitorRequests(
            self.connection_string,
            self.connection_port,
            channel_name,
            callback_function,
        )
        
    async def joinSubscriberGroup(self, channel_name, subscriber_group_name, callback_function):
        vlog.info(f"ARTEMIS_HANDLER: Joining subscriber group: {subscriber_group_name} on channel {channel_name}")
        await group.joinGroup(
            self.connection_string,
            self.connection_port,
            channel_name,
            subscriber_group_name,
            callback_function,
        )
